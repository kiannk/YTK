// =============================
// نمایش محصولات در products.html
// =============================
function loadProducts() {
  const productList = document.getElementById("product-list");
  if (!productList) return;

  const products = JSON.parse(localStorage.getItem("products")) || [];

  if (products.length === 0) {
    productList.innerHTML = "<p>هیچ محصولی ثبت نشده است.</p>";
    return;
  }

  products.forEach((product, index) => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <p>${product.price.toLocaleString()} تومان</p>
      <button onclick="showPopup(${index})">مشاهده و خرید</button>
    `;
    productList.appendChild(div);
  });
}

// =============================
// نمایش پنجره خرید و افزودن به سبد
// =============================
function showPopup(index) {
  const products = JSON.parse(localStorage.getItem("products")) || [];
  const product = products[index];

  const quantity = prompt(`چه تعداد از "${product.name}" می‌خواهید؟`, 1);
  if (quantity === null || isNaN(quantity) || quantity < 1) return;

  let basket = JSON.parse(localStorage.getItem("basket")) || [];
  basket.push({
    name: product.name,
    price: product.price,
    quantity: parseInt(quantity),
    image: product.image,
  });

  localStorage.setItem("basket", JSON.stringify(basket));
  alert("✅ به سبد خرید اضافه شد");
}

// =============================
// بارگذاری سبد خرید در basket.html
// =============================
function loadBasket() {
  const container = document.getElementById("cart-container");
  const totalPriceBox = document.getElementById("total-price");

  if (!container || !totalPriceBox) return;

  const basket = JSON.parse(localStorage.getItem("basket")) || [];
  container.innerHTML = "";

  if (basket.length === 0) {
    container.innerHTML = "<p>سبد خرید خالی است</p>";
    totalPriceBox.textContent = "";
    return;
  }

  let total = 0;

  basket.forEach((item, index) => {
    const price = item.price * item.quantity;
    total += price;

    const div = document.createElement("div");
    div.className = "product";

    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}" />
      <h3>${item.name}</h3>
      <p>تعداد: ${item.quantity}</p>
      <p>قیمت واحد: ${item.price.toLocaleString()} تومان</p>
      <p>قیمت کل: ${price.toLocaleString()} تومان</p>
      <button onclick="removeItem(${index})">❌ حذف</button>
    `;

    container.appendChild(div);
  });

  totalPriceBox.innerHTML = `<h3>💰 قیمت نهایی: ${total.toLocaleString()} تومان</h3>`;
}

// =============================
// حذف محصول از سبد
// =============================
function removeItem(index) {
  let basket = JSON.parse(localStorage.getItem("basket")) || [];
  basket.splice(index, 1);
  localStorage.setItem("basket", JSON.stringify(basket));
  loadBasket();
}

// =============================
// ارسال اطلاعات به واتساپ
// =============================
function sendToWhatsApp() {
  const basket = JSON.parse(localStorage.getItem("basket")) || [];
  if (basket.length === 0) {
    alert("سبد خرید خالی است");
    return;
  }

  let message = "🛒 خرید جدید:\n";
  let total = 0;

  basket.forEach((item) => {
    const price = item.price * item.quantity;
    total += price;
    message += `🔹 ${item.name} | ${item.quantity} عدد | ${price.toLocaleString()} تومان\n`;
  });

  message += `\n💰 مجموع کل: ${total.toLocaleString()} تومان`;

  const phoneNumber = "989123456789"; // ← شماره واتساپ خودت با 98 بدون +
  const encodedMessage = encodeURIComponent(message);
  const url = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;

  window.location.href = url;
}

// =============================
// اجرای مناسب در هر صفحه
// =============================
window.onload = () => {
  loadProducts();  // فقط در products.html کار می‌کنه
  loadBasket();    // فقط در basket.html کار می‌کنه
};